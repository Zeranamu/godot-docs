github_url

:   hide

# OpenXRSpatialComponentPersistenceList {#class_OpenXRSpatialComponentPersistenceList}

**Experimental:** This class may be changed or removed in future
versions.

**Inherits:**
`OpenXRSpatialComponentData<class_OpenXRSpatialComponentData>`{.interpreted-text
role="ref"} **\<** `RefCounted<class_RefCounted>`{.interpreted-text
role="ref"} **\<** `Object<class_Object>`{.interpreted-text role="ref"}

Object for storing the query persistence result data.

::: rst-class
classref-introduction-group
:::

## Description

Object for storing the query persistence result data when calling
`OpenXRSpatialEntityExtension.query_snapshot()<class_OpenXRSpatialEntityExtension_method_query_snapshot>`{.interpreted-text
role="ref"}.

::: rst-class
classref-reftable-group
:::

## Methods

::: rst-class
classref-section-separator
:::

------------------------------------------------------------------------

::: rst-class
classref-descriptions-group
:::

## Method Descriptions

::: {#class_OpenXRSpatialComponentPersistenceList_method_get_persistent_state}
::: rst-class
classref-method
:::
:::

`int<class_int>`{.interpreted-text role="ref"}
**get_persistent_state**(index: `int<class_int>`{.interpreted-text
role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_OpenXRSpatialComponentPersistenceList_method_get_persistent_state>`{.interpreted-text
role="ref"}

Returns the persistent state (`XrSpatialPersistenceStateEXT`) for the
entity at this `index`.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_OpenXRSpatialComponentPersistenceList_method_get_persistent_uuid}
::: rst-class
classref-method
:::
:::

`String<class_String>`{.interpreted-text role="ref"}
**get_persistent_uuid**(index: `int<class_int>`{.interpreted-text
role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_OpenXRSpatialComponentPersistenceList_method_get_persistent_uuid>`{.interpreted-text
role="ref"}

Returns the persistent uuid for the entity at this `index`.
