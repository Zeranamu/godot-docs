github_url

:   hide

# NavigationServer3DManager {#class_NavigationServer3DManager}

**Inherits:** `Object<class_Object>`{.interpreted-text role="ref"}

A singleton for managing
`NavigationServer3D<class_NavigationServer3D>`{.interpreted-text
role="ref"} implementations.

::: rst-class
classref-introduction-group
:::

## Description

**NavigationServer3DManager** is the API for registering
`NavigationServer3D<class_NavigationServer3D>`{.interpreted-text
role="ref"} implementations and setting the default implementation.

**Note:** It is not possible to switch servers at runtime. This class is
only used on startup at the server initialization level.

::: rst-class
classref-reftable-group
:::

## Methods

::: rst-class
classref-section-separator
:::

------------------------------------------------------------------------

::: rst-class
classref-descriptions-group
:::

## Method Descriptions

::: {#class_NavigationServer3DManager_method_register_server}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**register_server**(name: `String<class_String>`{.interpreted-text
role="ref"}, create_callback:
`Callable<class_Callable>`{.interpreted-text role="ref"})
`🔗<class_NavigationServer3DManager_method_register_server>`{.interpreted-text
role="ref"}

Registers a
`NavigationServer3D<class_NavigationServer3D>`{.interpreted-text
role="ref"} implementation by passing a `name` and a
`Callable<class_Callable>`{.interpreted-text role="ref"} that returns a
`NavigationServer3D<class_NavigationServer3D>`{.interpreted-text
role="ref"} object.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_NavigationServer3DManager_method_set_default_server}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**set_default_server**(name: `String<class_String>`{.interpreted-text
role="ref"}, priority: `int<class_int>`{.interpreted-text role="ref"})
`🔗<class_NavigationServer3DManager_method_set_default_server>`{.interpreted-text
role="ref"}

Sets the default
`NavigationServer3D<class_NavigationServer3D>`{.interpreted-text
role="ref"} implementation to the one identified by `name`, if
`priority` is greater than the priority of the current default
implementation.
