github_url

:   hide

# ChainIK3D {#class_ChainIK3D}

**Inherits:** `IKModifier3D<class_IKModifier3D>`{.interpreted-text
role="ref"} **\<**
`SkeletonModifier3D<class_SkeletonModifier3D>`{.interpreted-text
role="ref"} **\<** `Node3D<class_Node3D>`{.interpreted-text role="ref"}
**\<** `Node<class_Node>`{.interpreted-text role="ref"} **\<**
`Object<class_Object>`{.interpreted-text role="ref"}

**Inherited By:** `IterateIK3D<class_IterateIK3D>`{.interpreted-text
role="ref"}, `SplineIK3D<class_SplineIK3D>`{.interpreted-text
role="ref"}

A `SkeletonModifier3D<class_SkeletonModifier3D>`{.interpreted-text
role="ref"} to apply inverse kinematics to bone chains containing an
arbitrary number of bones.

::: rst-class
classref-introduction-group
:::

## Description

Base class of
`SkeletonModifier3D<class_SkeletonModifier3D>`{.interpreted-text
role="ref"} that automatically generates a joint list from the bones
between the root bone and the end bone.

::: rst-class
classref-reftable-group
:::

## Methods

::: rst-class
classref-section-separator
:::

------------------------------------------------------------------------

::: rst-class
classref-descriptions-group
:::

## Method Descriptions

::: {#class_ChainIK3D_method_get_end_bone}
::: rst-class
classref-method
:::
:::

`int<class_int>`{.interpreted-text role="ref"} **get_end_bone**(index:
`int<class_int>`{.interpreted-text role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"} `🔗<class_ChainIK3D_method_get_end_bone>`{.interpreted-text
role="ref"}

Returns the end bone index of the bone chain.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_ChainIK3D_method_get_end_bone_direction}
::: rst-class
classref-method
:::
:::

`BoneDirection<enum_SkeletonModifier3D_BoneDirection>`{.interpreted-text
role="ref"} **get_end_bone_direction**(index:
`int<class_int>`{.interpreted-text role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_ChainIK3D_method_get_end_bone_direction>`{.interpreted-text
role="ref"}

Returns the tail direction of the end bone of the bone chain when
`is_end_bone_extended()<class_ChainIK3D_method_is_end_bone_extended>`{.interpreted-text
role="ref"} is `true`.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_ChainIK3D_method_get_end_bone_length}
::: rst-class
classref-method
:::
:::

`float<class_float>`{.interpreted-text role="ref"}
**get_end_bone_length**(index: `int<class_int>`{.interpreted-text
role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_ChainIK3D_method_get_end_bone_length>`{.interpreted-text
role="ref"}

Returns the end bone tail length of the bone chain when
`is_end_bone_extended()<class_ChainIK3D_method_is_end_bone_extended>`{.interpreted-text
role="ref"} is `true`.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_ChainIK3D_method_get_end_bone_name}
::: rst-class
classref-method
:::
:::

`String<class_String>`{.interpreted-text role="ref"}
**get_end_bone_name**(index: `int<class_int>`{.interpreted-text
role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_ChainIK3D_method_get_end_bone_name>`{.interpreted-text
role="ref"}

Returns the end bone name of the bone chain.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_ChainIK3D_method_get_joint_bone}
::: rst-class
classref-method
:::
:::

`int<class_int>`{.interpreted-text role="ref"} **get_joint_bone**(index:
`int<class_int>`{.interpreted-text role="ref"}, joint:
`int<class_int>`{.interpreted-text role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_ChainIK3D_method_get_joint_bone>`{.interpreted-text
role="ref"}

Returns the bone index at `joint` in the bone chain\'s joint list.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_ChainIK3D_method_get_joint_bone_name}
::: rst-class
classref-method
:::
:::

`String<class_String>`{.interpreted-text role="ref"}
**get_joint_bone_name**(index: `int<class_int>`{.interpreted-text
role="ref"}, joint: `int<class_int>`{.interpreted-text role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_ChainIK3D_method_get_joint_bone_name>`{.interpreted-text
role="ref"}

Returns the bone name at `joint` in the bone chain\'s joint list.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_ChainIK3D_method_get_joint_count}
::: rst-class
classref-method
:::
:::

`int<class_int>`{.interpreted-text role="ref"}
**get_joint_count**(index: `int<class_int>`{.interpreted-text
role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_ChainIK3D_method_get_joint_count>`{.interpreted-text
role="ref"}

Returns the joint count of the bone chain\'s joint list.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_ChainIK3D_method_get_root_bone}
::: rst-class
classref-method
:::
:::

`int<class_int>`{.interpreted-text role="ref"} **get_root_bone**(index:
`int<class_int>`{.interpreted-text role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_ChainIK3D_method_get_root_bone>`{.interpreted-text role="ref"}

Returns the root bone index of the bone chain.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_ChainIK3D_method_get_root_bone_name}
::: rst-class
classref-method
:::
:::

`String<class_String>`{.interpreted-text role="ref"}
**get_root_bone_name**(index: `int<class_int>`{.interpreted-text
role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_ChainIK3D_method_get_root_bone_name>`{.interpreted-text
role="ref"}

Returns the root bone name of the bone chain.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_ChainIK3D_method_is_end_bone_extended}
::: rst-class
classref-method
:::
:::

`bool<class_bool>`{.interpreted-text role="ref"}
**is_end_bone_extended**(index: `int<class_int>`{.interpreted-text
role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_ChainIK3D_method_is_end_bone_extended>`{.interpreted-text
role="ref"}

Returns `true` if the end bone is extended to have a tail.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_ChainIK3D_method_set_end_bone}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**set_end_bone**(index: `int<class_int>`{.interpreted-text role="ref"},
bone: `int<class_int>`{.interpreted-text role="ref"})
`🔗<class_ChainIK3D_method_set_end_bone>`{.interpreted-text role="ref"}

Sets the end bone index of the bone chain.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_ChainIK3D_method_set_end_bone_direction}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**set_end_bone_direction**(index: `int<class_int>`{.interpreted-text
role="ref"}, bone_direction:
`BoneDirection<enum_SkeletonModifier3D_BoneDirection>`{.interpreted-text
role="ref"})
`🔗<class_ChainIK3D_method_set_end_bone_direction>`{.interpreted-text
role="ref"}

Sets the end bone tail direction of the bone chain when
`is_end_bone_extended()<class_ChainIK3D_method_is_end_bone_extended>`{.interpreted-text
role="ref"} is `true`.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_ChainIK3D_method_set_end_bone_length}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**set_end_bone_length**(index: `int<class_int>`{.interpreted-text
role="ref"}, length: `float<class_float>`{.interpreted-text role="ref"})
`🔗<class_ChainIK3D_method_set_end_bone_length>`{.interpreted-text
role="ref"}

Sets the end bone tail length of the bone chain when
`is_end_bone_extended()<class_ChainIK3D_method_is_end_bone_extended>`{.interpreted-text
role="ref"} is `true`.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_ChainIK3D_method_set_end_bone_name}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**set_end_bone_name**(index: `int<class_int>`{.interpreted-text
role="ref"}, bone_name: `String<class_String>`{.interpreted-text
role="ref"})
`🔗<class_ChainIK3D_method_set_end_bone_name>`{.interpreted-text
role="ref"}

Sets the end bone name of the bone chain.

**Note:** The end bone must be the root bone or a child of the root
bone. If they are the same, the tail must be extended by
`set_extend_end_bone()<class_ChainIK3D_method_set_extend_end_bone>`{.interpreted-text
role="ref"} to modify the bone.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_ChainIK3D_method_set_extend_end_bone}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**set_extend_end_bone**(index: `int<class_int>`{.interpreted-text
role="ref"}, enabled: `bool<class_bool>`{.interpreted-text role="ref"})
`🔗<class_ChainIK3D_method_set_extend_end_bone>`{.interpreted-text
role="ref"}

If `enabled` is `true`, the end bone is extended to have a tail.

The extended tail config is allocated to the last element in the joint
list. In other words, if you set `enabled` to `false`, the config of the
last element in the joint list has no effect in the simulated result.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_ChainIK3D_method_set_root_bone}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**set_root_bone**(index: `int<class_int>`{.interpreted-text role="ref"},
bone: `int<class_int>`{.interpreted-text role="ref"})
`🔗<class_ChainIK3D_method_set_root_bone>`{.interpreted-text role="ref"}

Sets the root bone index of the bone chain.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_ChainIK3D_method_set_root_bone_name}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**set_root_bone_name**(index: `int<class_int>`{.interpreted-text
role="ref"}, bone_name: `String<class_String>`{.interpreted-text
role="ref"})
`🔗<class_ChainIK3D_method_set_root_bone_name>`{.interpreted-text
role="ref"}

Sets the root bone name of the bone chain.
