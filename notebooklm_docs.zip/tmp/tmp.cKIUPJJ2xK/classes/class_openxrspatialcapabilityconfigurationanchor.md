github_url

:   hide

# OpenXRSpatialCapabilityConfigurationAnchor {#class_OpenXRSpatialCapabilityConfigurationAnchor}

**Experimental:** This class may be changed or removed in future
versions.

**Inherits:**
`OpenXRSpatialCapabilityConfigurationBaseHeader<class_OpenXRSpatialCapabilityConfigurationBaseHeader>`{.interpreted-text
role="ref"} **\<** `RefCounted<class_RefCounted>`{.interpreted-text
role="ref"} **\<** `Object<class_Object>`{.interpreted-text role="ref"}

Configuration header for spatial anchors.

::: rst-class
classref-introduction-group
:::

## Description

Configuration header for spatial anchors. Pass this to
`OpenXRSpatialEntityExtension.create_spatial_context()<class_OpenXRSpatialEntityExtension_method_create_spatial_context>`{.interpreted-text
role="ref"} to create a spatial context with spatial anchor
capabilities.

::: rst-class
classref-reftable-group
:::

## Methods

::: rst-class
classref-section-separator
:::

------------------------------------------------------------------------

::: rst-class
classref-descriptions-group
:::

## Method Descriptions

::: {#class_OpenXRSpatialCapabilityConfigurationAnchor_method_get_enabled_components}
::: rst-class
classref-method
:::
:::

`PackedInt64Array<class_PackedInt64Array>`{.interpreted-text role="ref"}
**get_enabled_components**()
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_OpenXRSpatialCapabilityConfigurationAnchor_method_get_enabled_components>`{.interpreted-text
role="ref"}

Returns the components enabled by this configuration.

**Note:** Only valid after this configuration was used to create a
spatial context.
