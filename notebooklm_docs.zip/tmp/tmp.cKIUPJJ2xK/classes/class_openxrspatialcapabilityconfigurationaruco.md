github_url

:   hide

# OpenXRSpatialCapabilityConfigurationAruco {#class_OpenXRSpatialCapabilityConfigurationAruco}

**Experimental:** This class may be changed or removed in future
versions.

**Inherits:**
`OpenXRSpatialCapabilityConfigurationBaseHeader<class_OpenXRSpatialCapabilityConfigurationBaseHeader>`{.interpreted-text
role="ref"} **\<** `RefCounted<class_RefCounted>`{.interpreted-text
role="ref"} **\<** `Object<class_Object>`{.interpreted-text role="ref"}

Configuration header for Aruco markers.

::: rst-class
classref-introduction-group
:::

## Description

Configuration header for Aruco markers. Pass this to
`OpenXRSpatialEntityExtension.create_spatial_context()<class_OpenXRSpatialEntityExtension_method_create_spatial_context>`{.interpreted-text
role="ref"} to create a spatial context that can detect Aruco markers.

::: rst-class
classref-reftable-group
:::

## Properties

::: rst-class
classref-reftable-group
:::

## Methods

::: rst-class
classref-section-separator
:::

------------------------------------------------------------------------

::: rst-class
classref-descriptions-group
:::

## Enumerations

::: {#enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict}
::: rst-class
classref-enumeration
:::
:::

enum **ArucoDict**:
`🔗<enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict>`{.interpreted-text
role="ref"}

::: {#class_OpenXRSpatialCapabilityConfigurationAruco_constant_ARUCO_DICT_4X4_50}
::: rst-class
classref-enumeration-constant
:::
:::

`ArucoDict<enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict>`{.interpreted-text
role="ref"} **ARUCO_DICT_4X4_50** = `1`

4 by 4 pixel Aruco marker dictionary with 50 IDs.

::: {#class_OpenXRSpatialCapabilityConfigurationAruco_constant_ARUCO_DICT_4X4_100}
::: rst-class
classref-enumeration-constant
:::
:::

`ArucoDict<enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict>`{.interpreted-text
role="ref"} **ARUCO_DICT_4X4_100** = `2`

4 by 4 pixel Aruco marker dictionary with 100 IDs.

::: {#class_OpenXRSpatialCapabilityConfigurationAruco_constant_ARUCO_DICT_4X4_250}
::: rst-class
classref-enumeration-constant
:::
:::

`ArucoDict<enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict>`{.interpreted-text
role="ref"} **ARUCO_DICT_4X4_250** = `3`

4 by 4 pixel Aruco marker dictionary with 250 IDs.

::: {#class_OpenXRSpatialCapabilityConfigurationAruco_constant_ARUCO_DICT_4X4_1000}
::: rst-class
classref-enumeration-constant
:::
:::

`ArucoDict<enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict>`{.interpreted-text
role="ref"} **ARUCO_DICT_4X4_1000** = `4`

4 by 4 pixel Aruco marker dictionary with 1000 IDs.

::: {#class_OpenXRSpatialCapabilityConfigurationAruco_constant_ARUCO_DICT_5X5_50}
::: rst-class
classref-enumeration-constant
:::
:::

`ArucoDict<enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict>`{.interpreted-text
role="ref"} **ARUCO_DICT_5X5_50** = `5`

5 by 5 pixel Aruco marker dictionary with 50 IDs.

::: {#class_OpenXRSpatialCapabilityConfigurationAruco_constant_ARUCO_DICT_5X5_100}
::: rst-class
classref-enumeration-constant
:::
:::

`ArucoDict<enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict>`{.interpreted-text
role="ref"} **ARUCO_DICT_5X5_100** = `6`

5 by 5 pixel Aruco marker dictionary with 100 IDs.

::: {#class_OpenXRSpatialCapabilityConfigurationAruco_constant_ARUCO_DICT_5X5_250}
::: rst-class
classref-enumeration-constant
:::
:::

`ArucoDict<enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict>`{.interpreted-text
role="ref"} **ARUCO_DICT_5X5_250** = `7`

5 by 5 pixel Aruco marker dictionary with 250 IDs.

::: {#class_OpenXRSpatialCapabilityConfigurationAruco_constant_ARUCO_DICT_5X5_1000}
::: rst-class
classref-enumeration-constant
:::
:::

`ArucoDict<enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict>`{.interpreted-text
role="ref"} **ARUCO_DICT_5X5_1000** = `8`

5 by 5 pixel Aruco marker dictionary with 1000 IDs.

::: {#class_OpenXRSpatialCapabilityConfigurationAruco_constant_ARUCO_DICT_6X6_50}
::: rst-class
classref-enumeration-constant
:::
:::

`ArucoDict<enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict>`{.interpreted-text
role="ref"} **ARUCO_DICT_6X6_50** = `9`

6 by 6 pixel Aruco marker dictionary with 50 IDs.

::: {#class_OpenXRSpatialCapabilityConfigurationAruco_constant_ARUCO_DICT_6X6_100}
::: rst-class
classref-enumeration-constant
:::
:::

`ArucoDict<enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict>`{.interpreted-text
role="ref"} **ARUCO_DICT_6X6_100** = `10`

6 by 6 pixel Aruco marker dictionary with 100 IDs.

::: {#class_OpenXRSpatialCapabilityConfigurationAruco_constant_ARUCO_DICT_6X6_250}
::: rst-class
classref-enumeration-constant
:::
:::

`ArucoDict<enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict>`{.interpreted-text
role="ref"} **ARUCO_DICT_6X6_250** = `11`

6 by 6 pixel Aruco marker dictionary with 250 IDs.

::: {#class_OpenXRSpatialCapabilityConfigurationAruco_constant_ARUCO_DICT_6X6_1000}
::: rst-class
classref-enumeration-constant
:::
:::

`ArucoDict<enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict>`{.interpreted-text
role="ref"} **ARUCO_DICT_6X6_1000** = `12`

6 by 6 pixel Aruco marker dictionary with 1000 IDs.

::: {#class_OpenXRSpatialCapabilityConfigurationAruco_constant_ARUCO_DICT_7X7_50}
::: rst-class
classref-enumeration-constant
:::
:::

`ArucoDict<enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict>`{.interpreted-text
role="ref"} **ARUCO_DICT_7X7_50** = `13`

7 by 7 pixel Aruco marker dictionary with 50 IDs.

::: {#class_OpenXRSpatialCapabilityConfigurationAruco_constant_ARUCO_DICT_7X7_100}
::: rst-class
classref-enumeration-constant
:::
:::

`ArucoDict<enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict>`{.interpreted-text
role="ref"} **ARUCO_DICT_7X7_100** = `14`

7 by 7 pixel Aruco marker dictionary with 100 IDs.

::: {#class_OpenXRSpatialCapabilityConfigurationAruco_constant_ARUCO_DICT_7X7_250}
::: rst-class
classref-enumeration-constant
:::
:::

`ArucoDict<enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict>`{.interpreted-text
role="ref"} **ARUCO_DICT_7X7_250** = `15`

7 by 7 pixel Aruco marker dictionary with 250 IDs.

::: {#class_OpenXRSpatialCapabilityConfigurationAruco_constant_ARUCO_DICT_7X7_1000}
::: rst-class
classref-enumeration-constant
:::
:::

`ArucoDict<enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict>`{.interpreted-text
role="ref"} **ARUCO_DICT_7X7_1000** = `16`

7 by 7 pixel Aruco marker dictionary with 1000 IDs.

::: rst-class
classref-section-separator
:::

------------------------------------------------------------------------

::: rst-class
classref-descriptions-group
:::

## Property Descriptions

::: {#class_OpenXRSpatialCapabilityConfigurationAruco_property_aruco_dict}
::: rst-class
classref-property
:::
:::

`ArucoDict<enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict>`{.interpreted-text
role="ref"} **aruco_dict** = `16`
`🔗<class_OpenXRSpatialCapabilityConfigurationAruco_property_aruco_dict>`{.interpreted-text
role="ref"}

::: rst-class
classref-property-setget
:::

-   `void (No return value.)`{.interpreted-text role="abbr"}
    **set_aruco_dict**(value:
    `ArucoDict<enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict>`{.interpreted-text
    role="ref"})
-   `ArucoDict<enum_OpenXRSpatialCapabilityConfigurationAruco_ArucoDict>`{.interpreted-text
    role="ref"} **get_aruco_dict**()

Dictionary to use to decode Aruco markers.

**Note:** Must be set before using this configuration to create a
spatial context.

::: rst-class
classref-section-separator
:::

------------------------------------------------------------------------

::: rst-class
classref-descriptions-group
:::

## Method Descriptions

::: {#class_OpenXRSpatialCapabilityConfigurationAruco_method_get_enabled_components}
::: rst-class
classref-method
:::
:::

`PackedInt64Array<class_PackedInt64Array>`{.interpreted-text role="ref"}
**get_enabled_components**()
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_OpenXRSpatialCapabilityConfigurationAruco_method_get_enabled_components>`{.interpreted-text
role="ref"}

Returns the components enabled by this configuration.

**Note:** Only valid after this configuration was used to create a
spatial context.
