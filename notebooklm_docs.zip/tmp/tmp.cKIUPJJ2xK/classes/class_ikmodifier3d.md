github_url

:   hide

# IKModifier3D {#class_IKModifier3D}

**Inherits:**
`SkeletonModifier3D<class_SkeletonModifier3D>`{.interpreted-text
role="ref"} **\<** `Node3D<class_Node3D>`{.interpreted-text role="ref"}
**\<** `Node<class_Node>`{.interpreted-text role="ref"} **\<**
`Object<class_Object>`{.interpreted-text role="ref"}

**Inherited By:** `ChainIK3D<class_ChainIK3D>`{.interpreted-text
role="ref"}, `TwoBoneIK3D<class_TwoBoneIK3D>`{.interpreted-text
role="ref"}

A node for inverse kinematics which may modify more than one bone.

::: rst-class
classref-introduction-group
:::

## Description

Base class of
`SkeletonModifier3D<class_SkeletonModifier3D>`{.interpreted-text
role="ref"}s that has some joint lists and applies inverse kinematics.
This class has some structs, enums, and helper methods which are useful
to solve inverse kinematics.

::: rst-class
classref-reftable-group
:::

## Properties

::: rst-class
classref-reftable-group
:::

## Methods

::: rst-class
classref-section-separator
:::

------------------------------------------------------------------------

::: rst-class
classref-descriptions-group
:::

## Property Descriptions

::: {#class_IKModifier3D_property_mutable_bone_axes}
::: rst-class
classref-property
:::
:::

`bool<class_bool>`{.interpreted-text role="ref"} **mutable_bone_axes** =
`true`
`🔗<class_IKModifier3D_property_mutable_bone_axes>`{.interpreted-text
role="ref"}

::: rst-class
classref-property-setget
:::

-   `void (No return value.)`{.interpreted-text role="abbr"}
    **set_mutable_bone_axes**(value:
    `bool<class_bool>`{.interpreted-text role="ref"})
-   `bool<class_bool>`{.interpreted-text role="ref"}
    **are_bone_axes_mutable**()

If `true`, the solver retrieves the bone axis from the bone pose every
frame.

If `false`, the solver retrieves the bone axis from the bone rest and
caches it, which increases performance slightly, but position changes in
the bone pose made before processing this **IKModifier3D** are ignored.

::: rst-class
classref-section-separator
:::

------------------------------------------------------------------------

::: rst-class
classref-descriptions-group
:::

## Method Descriptions

::: {#class_IKModifier3D_method_clear_settings}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**clear_settings**()
`🔗<class_IKModifier3D_method_clear_settings>`{.interpreted-text
role="ref"}

Clears all settings.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_IKModifier3D_method_get_setting_count}
::: rst-class
classref-method
:::
:::

`int<class_int>`{.interpreted-text role="ref"} **get_setting_count**()
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_IKModifier3D_method_get_setting_count>`{.interpreted-text
role="ref"}

Returns the number of settings.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_IKModifier3D_method_reset}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"} **reset**()
`🔗<class_IKModifier3D_method_reset>`{.interpreted-text role="ref"}

Resets a state with respect to the current bone pose.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_IKModifier3D_method_set_setting_count}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**set_setting_count**(count: `int<class_int>`{.interpreted-text
role="ref"})
`🔗<class_IKModifier3D_method_set_setting_count>`{.interpreted-text
role="ref"}

Sets the number of settings.
