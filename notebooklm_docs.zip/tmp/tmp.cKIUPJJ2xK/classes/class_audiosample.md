github_url

:   hide

# AudioSample {#class_AudioSample}

**Experimental:** This class may be changed or removed in future
versions.

**Inherits:** `RefCounted<class_RefCounted>`{.interpreted-text
role="ref"} **\<** `Object<class_Object>`{.interpreted-text role="ref"}

Base class for audio samples.

::: rst-class
classref-introduction-group
:::

## Description

Base class for audio samples.
