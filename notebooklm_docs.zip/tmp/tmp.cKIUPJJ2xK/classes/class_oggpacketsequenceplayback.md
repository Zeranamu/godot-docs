github_url

:   hide

# OggPacketSequencePlayback {#class_OggPacketSequencePlayback}

**Inherits:** `RefCounted<class_RefCounted>`{.interpreted-text
role="ref"} **\<** `Object<class_Object>`{.interpreted-text role="ref"}

::: {.container .contribute}
There is currently no description for this class. Please help us by
[contributing
one](https://contributing.godotengine.org/en/latest/documentation/class_reference.html)!
:::
