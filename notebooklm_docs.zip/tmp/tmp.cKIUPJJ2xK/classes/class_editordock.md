github_url

:   hide

# EditorDock {#class_EditorDock}

**Experimental:** This class may be changed or removed in future
versions.

**Inherits:** `MarginContainer<class_MarginContainer>`{.interpreted-text
role="ref"} **\<** `Container<class_Container>`{.interpreted-text
role="ref"} **\<** `Control<class_Control>`{.interpreted-text
role="ref"} **\<** `CanvasItem<class_CanvasItem>`{.interpreted-text
role="ref"} **\<** `Node<class_Node>`{.interpreted-text role="ref"}
**\<** `Object<class_Object>`{.interpreted-text role="ref"}

**Inherited By:**
`FileSystemDock<class_FileSystemDock>`{.interpreted-text role="ref"}

Dockable container for the editor.

::: rst-class
classref-introduction-group
:::

## Description

EditorDock is a `Container<class_Container>`{.interpreted-text
role="ref"} node that can be docked in one of the editor\'s dock slots.
Docks are added by plugins to provide space for controls related to an
`EditorPlugin<class_EditorPlugin>`{.interpreted-text role="ref"}. The
editor comes with a few built-in docks, such as the Scene dock,
FileSystem dock, etc.

You can add a dock by using
`EditorPlugin.add_dock()<class_EditorPlugin_method_add_dock>`{.interpreted-text
role="ref"}. The dock can be customized by changing its properties.

    @tool
    extends EditorPlugin

    # Dock reference.
    var dock

    # Plugin initialization.
    func _enter_tree():
        dock = EditorDock.new()
        dock.title = "My Dock"
        dock.dock_icon = preload("./dock_icon.png")
        dock.default_slot = EditorPlugin.DOCK_SLOT_RIGHT_UL
        var dock_content = preload("./dock_content.tscn").instantiate()
        dock.add_child(dock_content)
        add_dock(dock)

    # Plugin clean-up.
    func _exit_tree():
        remove_dock(dock)
        dock.queue_free()
        dock = null

::: rst-class
classref-introduction-group
:::

## Tutorials

-   `Making plugins <../tutorials/plugins/editor/making_plugins>`{.interpreted-text
    role="doc"}

::: rst-class
classref-reftable-group
:::

## Properties

::: rst-class
classref-reftable-group
:::

## Methods

::: rst-class
classref-section-separator
:::

------------------------------------------------------------------------

::: rst-class
classref-descriptions-group
:::

## Enumerations

::: {#enum_EditorDock_DockLayout}
::: rst-class
classref-enumeration
:::
:::

flags **DockLayout**: `🔗<enum_EditorDock_DockLayout>`{.interpreted-text
role="ref"}

::: {#class_EditorDock_constant_DOCK_LAYOUT_VERTICAL}
::: rst-class
classref-enumeration-constant
:::
:::

`DockLayout<enum_EditorDock_DockLayout>`{.interpreted-text role="ref"}
**DOCK_LAYOUT_VERTICAL** = `1`

Allows placing the dock in the vertical dock slots on either side of the
editor.

::: {#class_EditorDock_constant_DOCK_LAYOUT_HORIZONTAL}
::: rst-class
classref-enumeration-constant
:::
:::

`DockLayout<enum_EditorDock_DockLayout>`{.interpreted-text role="ref"}
**DOCK_LAYOUT_HORIZONTAL** = `2`

Allows placing the dock in the editor\'s bottom panel.

::: {#class_EditorDock_constant_DOCK_LAYOUT_FLOATING}
::: rst-class
classref-enumeration-constant
:::
:::

`DockLayout<enum_EditorDock_DockLayout>`{.interpreted-text role="ref"}
**DOCK_LAYOUT_FLOATING** = `4`

Allows making the dock floating (opened as a separate window).

::: {#class_EditorDock_constant_DOCK_LAYOUT_ALL}
::: rst-class
classref-enumeration-constant
:::
:::

`DockLayout<enum_EditorDock_DockLayout>`{.interpreted-text role="ref"}
**DOCK_LAYOUT_ALL** = `7`

Allows placing the dock in all available slots.

::: rst-class
classref-section-separator
:::

------------------------------------------------------------------------

::: rst-class
classref-descriptions-group
:::

## Property Descriptions

::: {#class_EditorDock_property_available_layouts}
::: rst-class
classref-property
:::
:::

`BitField (This value is an integer composed as a bitmask of the following flags.)`{.interpreted-text
role="abbr"}\[`DockLayout<enum_EditorDock_DockLayout>`{.interpreted-text
role="ref"}\] **available_layouts** = `5`
`🔗<class_EditorDock_property_available_layouts>`{.interpreted-text
role="ref"}

::: rst-class
classref-property-setget
:::

-   `void (No return value.)`{.interpreted-text role="abbr"}
    **set_available_layouts**(value:
    `BitField (This value is an integer composed as a bitmask of the following flags.)`{.interpreted-text
    role="abbr"}\[`DockLayout<enum_EditorDock_DockLayout>`{.interpreted-text
    role="ref"}\])
-   `BitField (This value is an integer composed as a bitmask of the following flags.)`{.interpreted-text
    role="abbr"}\[`DockLayout<enum_EditorDock_DockLayout>`{.interpreted-text
    role="ref"}\] **get_available_layouts**()

The available layouts for this dock, as a bitmask. By default, the dock
allows vertical and floating layouts.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_EditorDock_property_default_slot}
::: rst-class
classref-property
:::
:::

`DockSlot<enum_EditorPlugin_DockSlot>`{.interpreted-text role="ref"}
**default_slot** = `-1`
`🔗<class_EditorDock_property_default_slot>`{.interpreted-text
role="ref"}

::: rst-class
classref-property-setget
:::

-   `void (No return value.)`{.interpreted-text role="abbr"}
    **set_default_slot**(value:
    `DockSlot<enum_EditorPlugin_DockSlot>`{.interpreted-text
    role="ref"})
-   `DockSlot<enum_EditorPlugin_DockSlot>`{.interpreted-text role="ref"}
    **get_default_slot**()

The default dock slot used when adding the dock with
`EditorPlugin.add_dock()<class_EditorPlugin_method_add_dock>`{.interpreted-text
role="ref"}.

After the dock is added, it can be moved to a different slot and the
editor will automatically remember its position between sessions. If you
remove and re-add the dock, it will be reset to default.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_EditorDock_property_dock_icon}
::: rst-class
classref-property
:::
:::

`Texture2D<class_Texture2D>`{.interpreted-text role="ref"} **dock_icon**
`🔗<class_EditorDock_property_dock_icon>`{.interpreted-text role="ref"}

::: rst-class
classref-property-setget
:::

-   `void (No return value.)`{.interpreted-text role="abbr"}
    **set_dock_icon**(value:
    `Texture2D<class_Texture2D>`{.interpreted-text role="ref"})
-   `Texture2D<class_Texture2D>`{.interpreted-text role="ref"}
    **get_dock_icon**()

The icon for the dock, as a texture. If specified, it will override
`icon_name<class_EditorDock_property_icon_name>`{.interpreted-text
role="ref"}.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_EditorDock_property_dock_shortcut}
::: rst-class
classref-property
:::
:::

`Shortcut<class_Shortcut>`{.interpreted-text role="ref"}
**dock_shortcut**
`🔗<class_EditorDock_property_dock_shortcut>`{.interpreted-text
role="ref"}

::: rst-class
classref-property-setget
:::

-   `void (No return value.)`{.interpreted-text role="abbr"}
    **set_dock_shortcut**(value:
    `Shortcut<class_Shortcut>`{.interpreted-text role="ref"})
-   `Shortcut<class_Shortcut>`{.interpreted-text role="ref"}
    **get_dock_shortcut**()

The shortcut used to open the dock. This property can only be set before
this dock is added via
`EditorPlugin.add_dock()<class_EditorPlugin_method_add_dock>`{.interpreted-text
role="ref"}.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_EditorDock_property_global}
::: rst-class
classref-property
:::
:::

`bool<class_bool>`{.interpreted-text role="ref"} **global** = `true`
`🔗<class_EditorDock_property_global>`{.interpreted-text role="ref"}

::: rst-class
classref-property-setget
:::

-   `void (No return value.)`{.interpreted-text role="abbr"}
    **set_global**(value: `bool<class_bool>`{.interpreted-text
    role="ref"})
-   `bool<class_bool>`{.interpreted-text role="ref"} **is_global**()

If `true`, the dock appears in the **Editor \> Editor Docks** menu and
can be closed. Non-global docks can still be closed using
`close()<class_EditorDock_method_close>`{.interpreted-text role="ref"}.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_EditorDock_property_icon_name}
::: rst-class
classref-property
:::
:::

`StringName<class_StringName>`{.interpreted-text role="ref"}
**icon_name** = `&""`
`🔗<class_EditorDock_property_icon_name>`{.interpreted-text role="ref"}

::: rst-class
classref-property-setget
:::

-   `void (No return value.)`{.interpreted-text role="abbr"}
    **set_icon_name**(value:
    `StringName<class_StringName>`{.interpreted-text role="ref"})
-   `StringName<class_StringName>`{.interpreted-text role="ref"}
    **get_icon_name**()

The icon for the dock, as a name from the `EditorIcons` theme type in
the editor theme. You can find the list of available icons
[here](https://godot-editor-icons.github.io/).

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_EditorDock_property_layout_key}
::: rst-class
classref-property
:::
:::

`String<class_String>`{.interpreted-text role="ref"} **layout_key** =
`""` `🔗<class_EditorDock_property_layout_key>`{.interpreted-text
role="ref"}

::: rst-class
classref-property-setget
:::

-   `void (No return value.)`{.interpreted-text role="abbr"}
    **set_layout_key**(value: `String<class_String>`{.interpreted-text
    role="ref"})
-   `String<class_String>`{.interpreted-text role="ref"}
    **get_layout_key**()

The key representing this dock in the editor\'s layout file. If empty,
the dock\'s displayed name will be used instead.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_EditorDock_property_title}
::: rst-class
classref-property
:::
:::

`String<class_String>`{.interpreted-text role="ref"} **title** = `""`
`🔗<class_EditorDock_property_title>`{.interpreted-text role="ref"}

::: rst-class
classref-property-setget
:::

-   `void (No return value.)`{.interpreted-text role="abbr"}
    **set_title**(value: `String<class_String>`{.interpreted-text
    role="ref"})
-   `String<class_String>`{.interpreted-text role="ref"} **get_title**()

The title of the dock\'s tab. If empty, the dock\'s
`Node.name<class_Node_property_name>`{.interpreted-text role="ref"} will
be used. If the name is auto-generated (contains `@`), the first
child\'s name will be used instead.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_EditorDock_property_title_color}
::: rst-class
classref-property
:::
:::

`Color<class_Color>`{.interpreted-text role="ref"} **title_color** =
`Color(0, 0, 0, 0)`
`🔗<class_EditorDock_property_title_color>`{.interpreted-text
role="ref"}

::: rst-class
classref-property-setget
:::

-   `void (No return value.)`{.interpreted-text role="abbr"}
    **set_title_color**(value: `Color<class_Color>`{.interpreted-text
    role="ref"})
-   `Color<class_Color>`{.interpreted-text role="ref"}
    **get_title_color**()

The color of the dock tab\'s title. If its alpha is `0.0`, the default
font color will be used.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_EditorDock_property_transient}
::: rst-class
classref-property
:::
:::

`bool<class_bool>`{.interpreted-text role="ref"} **transient** = `false`
`🔗<class_EditorDock_property_transient>`{.interpreted-text role="ref"}

::: rst-class
classref-property-setget
:::

-   `void (No return value.)`{.interpreted-text role="abbr"}
    **set_transient**(value: `bool<class_bool>`{.interpreted-text
    role="ref"})
-   `bool<class_bool>`{.interpreted-text role="ref"} **is_transient**()

If `true`, the dock is not automatically opened or closed when loading
an editor layout, only moved. It also can\'t be opened using a shortcut.
This is meant for docks that are opened and closed in specific cases,
such as when selecting a `TileMap<class_TileMap>`{.interpreted-text
role="ref"} or `AnimationTree<class_AnimationTree>`{.interpreted-text
role="ref"} node.

::: rst-class
classref-section-separator
:::

------------------------------------------------------------------------

::: rst-class
classref-descriptions-group
:::

## Method Descriptions

::: {#class_EditorDock_private_method__load_layout_from_config}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**\_load_layout_from_config**(config:
`ConfigFile<class_ConfigFile>`{.interpreted-text role="ref"}, section:
`String<class_String>`{.interpreted-text role="ref"})
`virtual (This method should typically be overridden by the user to have any effect.)`{.interpreted-text
role="abbr"}
`🔗<class_EditorDock_private_method__load_layout_from_config>`{.interpreted-text
role="ref"}

Implement this method to handle loading this dock\'s layout. It\'s
equivalent to
`EditorPlugin._set_window_layout()<class_EditorPlugin_private_method__set_window_layout>`{.interpreted-text
role="ref"}. `section` is a unique section based on
`layout_key<class_EditorDock_property_layout_key>`{.interpreted-text
role="ref"}.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_EditorDock_private_method__save_layout_to_config}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**\_save_layout_to_config**(config:
`ConfigFile<class_ConfigFile>`{.interpreted-text role="ref"}, section:
`String<class_String>`{.interpreted-text role="ref"})
`virtual (This method should typically be overridden by the user to have any effect.)`{.interpreted-text
role="abbr"}
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_EditorDock_private_method__save_layout_to_config>`{.interpreted-text
role="ref"}

Implement this method to handle saving this dock\'s layout. It\'s
equivalent to
`EditorPlugin._get_window_layout()<class_EditorPlugin_private_method__get_window_layout>`{.interpreted-text
role="ref"}. `section` is a unique section based on
`layout_key<class_EditorDock_property_layout_key>`{.interpreted-text
role="ref"}.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_EditorDock_private_method__update_layout}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**\_update_layout**(layout: `int<class_int>`{.interpreted-text
role="ref"})
`virtual (This method should typically be overridden by the user to have any effect.)`{.interpreted-text
role="abbr"}
`🔗<class_EditorDock_private_method__update_layout>`{.interpreted-text
role="ref"}

Implement this method to handle the layout switching for this dock.
`layout` is one of the
`DockLayout<enum_EditorDock_DockLayout>`{.interpreted-text role="ref"}
constants.

    _update_layout(layout):
        box_container.vertical = (layout == DOCK_LAYOUT_VERTICAL)

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_EditorDock_method_close}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"} **close**()
`🔗<class_EditorDock_method_close>`{.interpreted-text role="ref"}

Closes the dock, making its tab hidden.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_EditorDock_method_open}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"} **open**()
`🔗<class_EditorDock_method_open>`{.interpreted-text role="ref"}

Opens the dock. It will appear in the last used dock slot. If the dock
has no default slot, it will be opened floating.
