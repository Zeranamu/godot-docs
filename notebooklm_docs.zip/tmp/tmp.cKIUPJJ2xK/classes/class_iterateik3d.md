github_url

:   hide

# IterateIK3D {#class_IterateIK3D}

**Inherits:** `ChainIK3D<class_ChainIK3D>`{.interpreted-text role="ref"}
**\<** `IKModifier3D<class_IKModifier3D>`{.interpreted-text role="ref"}
**\<** `SkeletonModifier3D<class_SkeletonModifier3D>`{.interpreted-text
role="ref"} **\<** `Node3D<class_Node3D>`{.interpreted-text role="ref"}
**\<** `Node<class_Node>`{.interpreted-text role="ref"} **\<**
`Object<class_Object>`{.interpreted-text role="ref"}

**Inherited By:** `CCDIK3D<class_CCDIK3D>`{.interpreted-text
role="ref"}, `FABRIK3D<class_FABRIK3D>`{.interpreted-text role="ref"},
`JacobianIK3D<class_JacobianIK3D>`{.interpreted-text role="ref"}

A `SkeletonModifier3D<class_SkeletonModifier3D>`{.interpreted-text
role="ref"} to approach the goal by repeating small rotations.

::: rst-class
classref-introduction-group
:::

## Description

Base class of
`SkeletonModifier3D<class_SkeletonModifier3D>`{.interpreted-text
role="ref"} to approach the goal by repeating small rotations.

Each bone chain (setting) has one effector, which is processed in order
of the setting list. You can set some limitations for each joint.

::: rst-class
classref-reftable-group
:::

## Properties

::: rst-class
classref-reftable-group
:::

## Methods

::: rst-class
classref-section-separator
:::

------------------------------------------------------------------------

::: rst-class
classref-descriptions-group
:::

## Property Descriptions

::: {#class_IterateIK3D_property_angular_delta_limit}
::: rst-class
classref-property
:::
:::

`float<class_float>`{.interpreted-text role="ref"}
**angular_delta_limit** = `0.034906585`
`🔗<class_IterateIK3D_property_angular_delta_limit>`{.interpreted-text
role="ref"}

::: rst-class
classref-property-setget
:::

-   `void (No return value.)`{.interpreted-text role="abbr"}
    **set_angular_delta_limit**(value:
    `float<class_float>`{.interpreted-text role="ref"})
-   `float<class_float>`{.interpreted-text role="ref"}
    **get_angular_delta_limit**()

The maximum amount each bone can rotate in a single iteration.

**Note:** This limitation is applied during each iteration. For example,
if
`max_iterations<class_IterateIK3D_property_max_iterations>`{.interpreted-text
role="ref"} is `4` and
`angular_delta_limit<class_IterateIK3D_property_angular_delta_limit>`{.interpreted-text
role="ref"} is `5` degrees, the maximum rotation possible in a single
frame is `20` degrees.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_IterateIK3D_property_deterministic}
::: rst-class
classref-property
:::
:::

`bool<class_bool>`{.interpreted-text role="ref"} **deterministic** =
`false` `🔗<class_IterateIK3D_property_deterministic>`{.interpreted-text
role="ref"}

::: rst-class
classref-property-setget
:::

-   `void (No return value.)`{.interpreted-text role="abbr"}
    **set_deterministic**(value: `bool<class_bool>`{.interpreted-text
    role="ref"})
-   `bool<class_bool>`{.interpreted-text role="ref"}
    **is_deterministic**()

If `false`, the result is calculated from the previous frame\'s
**IterateIK3D** result as the initial state.

If `true`, the previous frame\'s **IterateIK3D** result is discarded. At
this point, the new result is calculated from the bone pose excluding
the **IterateIK3D** as the initial state. This means the result will be
always equal as long as the target position and the previous bone pose
are the same. However, if
`angular_delta_limit<class_IterateIK3D_property_angular_delta_limit>`{.interpreted-text
role="ref"} and
`max_iterations<class_IterateIK3D_property_max_iterations>`{.interpreted-text
role="ref"} are set too small, the end bone of the chain will never
reach the target.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_IterateIK3D_property_max_iterations}
::: rst-class
classref-property
:::
:::

`int<class_int>`{.interpreted-text role="ref"} **max_iterations** = `4`
`🔗<class_IterateIK3D_property_max_iterations>`{.interpreted-text
role="ref"}

::: rst-class
classref-property-setget
:::

-   `void (No return value.)`{.interpreted-text role="abbr"}
    **set_max_iterations**(value: `int<class_int>`{.interpreted-text
    role="ref"})
-   `int<class_int>`{.interpreted-text role="ref"}
    **get_max_iterations**()

The number of iteration loops used by the IK solver to produce more
accurate results.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_IterateIK3D_property_min_distance}
::: rst-class
classref-property
:::
:::

`float<class_float>`{.interpreted-text role="ref"} **min_distance** =
`0.001` `🔗<class_IterateIK3D_property_min_distance>`{.interpreted-text
role="ref"}

::: rst-class
classref-property-setget
:::

-   `void (No return value.)`{.interpreted-text role="abbr"}
    **set_min_distance**(value: `float<class_float>`{.interpreted-text
    role="ref"})
-   `float<class_float>`{.interpreted-text role="ref"}
    **get_min_distance**()

The minimum distance between the end bone and the target. If the
distance is below this value, the IK solver stops any further
iterations.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_IterateIK3D_property_setting_count}
::: rst-class
classref-property
:::
:::

`int<class_int>`{.interpreted-text role="ref"} **setting_count** = `0`
`🔗<class_IterateIK3D_property_setting_count>`{.interpreted-text
role="ref"}

::: rst-class
classref-property-setget
:::

-   `void (No return value.)`{.interpreted-text role="abbr"}
    **set_setting_count**(value: `int<class_int>`{.interpreted-text
    role="ref"})
-   `int<class_int>`{.interpreted-text role="ref"}
    **get_setting_count**()

The number of settings.

::: rst-class
classref-section-separator
:::

------------------------------------------------------------------------

::: rst-class
classref-descriptions-group
:::

## Method Descriptions

::: {#class_IterateIK3D_method_get_joint_limitation}
::: rst-class
classref-method
:::
:::

`JointLimitation3D<class_JointLimitation3D>`{.interpreted-text
role="ref"} **get_joint_limitation**(index:
`int<class_int>`{.interpreted-text role="ref"}, joint:
`int<class_int>`{.interpreted-text role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_IterateIK3D_method_get_joint_limitation>`{.interpreted-text
role="ref"}

Returns the joint limitation at `joint` in the bone chain\'s joint list.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_IterateIK3D_method_get_joint_limitation_right_axis}
::: rst-class
classref-method
:::
:::

`SecondaryDirection<enum_SkeletonModifier3D_SecondaryDirection>`{.interpreted-text
role="ref"} **get_joint_limitation_right_axis**(index:
`int<class_int>`{.interpreted-text role="ref"}, joint:
`int<class_int>`{.interpreted-text role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_IterateIK3D_method_get_joint_limitation_right_axis>`{.interpreted-text
role="ref"}

Returns the joint limitation right axis at `joint` in the bone chain\'s
joint list.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_IterateIK3D_method_get_joint_limitation_right_axis_vector}
::: rst-class
classref-method
:::
:::

`Vector3<class_Vector3>`{.interpreted-text role="ref"}
**get_joint_limitation_right_axis_vector**(index:
`int<class_int>`{.interpreted-text role="ref"}, joint:
`int<class_int>`{.interpreted-text role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_IterateIK3D_method_get_joint_limitation_right_axis_vector>`{.interpreted-text
role="ref"}

Returns the joint limitation right axis vector at `joint` in the bone
chain\'s joint list.

If
`get_joint_limitation_right_axis()<class_IterateIK3D_method_get_joint_limitation_right_axis>`{.interpreted-text
role="ref"} is
`SkeletonModifier3D.SECONDARY_DIRECTION_NONE<class_SkeletonModifier3D_constant_SECONDARY_DIRECTION_NONE>`{.interpreted-text
role="ref"}, this method returns `Vector3(0, 0, 0)`.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_IterateIK3D_method_get_joint_limitation_rotation_offset}
::: rst-class
classref-method
:::
:::

`Quaternion<class_Quaternion>`{.interpreted-text role="ref"}
**get_joint_limitation_rotation_offset**(index:
`int<class_int>`{.interpreted-text role="ref"}, joint:
`int<class_int>`{.interpreted-text role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_IterateIK3D_method_get_joint_limitation_rotation_offset>`{.interpreted-text
role="ref"}

Returns the joint limitation rotation offset at `joint` in the bone
chain\'s joint list.

Rotation is done in the local space which is constructed by the bone
direction (in general parent to child) as the +Y axis and
`get_joint_limitation_right_axis_vector()<class_IterateIK3D_method_get_joint_limitation_right_axis_vector>`{.interpreted-text
role="ref"} as the +X axis.

If the +X and +Y axes are not orthogonal, the +X axis is implicitly
modified to make it orthogonal.

Also, if the length of
`get_joint_limitation_right_axis_vector()<class_IterateIK3D_method_get_joint_limitation_right_axis_vector>`{.interpreted-text
role="ref"} is zero, the space is created by rotating the bone rest
using the shortest arc that rotates the +Y axis of the bone rest to
match the bone direction.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_IterateIK3D_method_get_joint_rotation_axis}
::: rst-class
classref-method
:::
:::

`RotationAxis<enum_SkeletonModifier3D_RotationAxis>`{.interpreted-text
role="ref"} **get_joint_rotation_axis**(index:
`int<class_int>`{.interpreted-text role="ref"}, joint:
`int<class_int>`{.interpreted-text role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_IterateIK3D_method_get_joint_rotation_axis>`{.interpreted-text
role="ref"}

Returns the rotation axis at `joint` in the bone chain\'s joint list.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_IterateIK3D_method_get_joint_rotation_axis_vector}
::: rst-class
classref-method
:::
:::

`Vector3<class_Vector3>`{.interpreted-text role="ref"}
**get_joint_rotation_axis_vector**(index:
`int<class_int>`{.interpreted-text role="ref"}, joint:
`int<class_int>`{.interpreted-text role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_IterateIK3D_method_get_joint_rotation_axis_vector>`{.interpreted-text
role="ref"}

Returns the rotation axis vector for the specified joint in the bone
chain. This vector represents the axis around which the joint can
rotate. It is determined based on the rotation axis set for the joint.

If
`get_joint_rotation_axis()<class_IterateIK3D_method_get_joint_rotation_axis>`{.interpreted-text
role="ref"} is
`SkeletonModifier3D.ROTATION_AXIS_ALL<class_SkeletonModifier3D_constant_ROTATION_AXIS_ALL>`{.interpreted-text
role="ref"}, this method returns `Vector3(0, 0, 0)`.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_IterateIK3D_method_get_target_node}
::: rst-class
classref-method
:::
:::

`NodePath<class_NodePath>`{.interpreted-text role="ref"}
**get_target_node**(index: `int<class_int>`{.interpreted-text
role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_IterateIK3D_method_get_target_node>`{.interpreted-text
role="ref"}

Returns the target node that the end bone is trying to reach.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_IterateIK3D_method_set_joint_limitation}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**set_joint_limitation**(index: `int<class_int>`{.interpreted-text
role="ref"}, joint: `int<class_int>`{.interpreted-text role="ref"},
limitation:
`JointLimitation3D<class_JointLimitation3D>`{.interpreted-text
role="ref"})
`🔗<class_IterateIK3D_method_set_joint_limitation>`{.interpreted-text
role="ref"}

Sets the joint limitation at `joint` in the bone chain\'s joint list.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_IterateIK3D_method_set_joint_limitation_right_axis}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**set_joint_limitation_right_axis**(index:
`int<class_int>`{.interpreted-text role="ref"}, joint:
`int<class_int>`{.interpreted-text role="ref"}, direction:
`SecondaryDirection<enum_SkeletonModifier3D_SecondaryDirection>`{.interpreted-text
role="ref"})
`🔗<class_IterateIK3D_method_set_joint_limitation_right_axis>`{.interpreted-text
role="ref"}

Sets the joint limitation right axis at `joint` in the bone chain\'s
joint list.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_IterateIK3D_method_set_joint_limitation_right_axis_vector}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**set_joint_limitation_right_axis_vector**(index:
`int<class_int>`{.interpreted-text role="ref"}, joint:
`int<class_int>`{.interpreted-text role="ref"}, vector:
`Vector3<class_Vector3>`{.interpreted-text role="ref"})
`🔗<class_IterateIK3D_method_set_joint_limitation_right_axis_vector>`{.interpreted-text
role="ref"}

Sets the optional joint limitation right axis vector at `joint` in the
bone chain\'s joint list.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_IterateIK3D_method_set_joint_limitation_rotation_offset}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**set_joint_limitation_rotation_offset**(index:
`int<class_int>`{.interpreted-text role="ref"}, joint:
`int<class_int>`{.interpreted-text role="ref"}, offset:
`Quaternion<class_Quaternion>`{.interpreted-text role="ref"})
`🔗<class_IterateIK3D_method_set_joint_limitation_rotation_offset>`{.interpreted-text
role="ref"}

Sets the joint limitation rotation offset at `joint` in the bone
chain\'s joint list.

Rotation is done in the local space which is constructed by the bone
direction (in general parent to child) as the +Y axis and
`get_joint_limitation_right_axis_vector()<class_IterateIK3D_method_get_joint_limitation_right_axis_vector>`{.interpreted-text
role="ref"} as the +X axis.

If the +X and +Y axes are not orthogonal, the +X axis is implicitly
modified to make it orthogonal.

Also, if the length of
`get_joint_limitation_right_axis_vector()<class_IterateIK3D_method_get_joint_limitation_right_axis_vector>`{.interpreted-text
role="ref"} is zero, the space is created by rotating the bone rest
using the shortest arc that rotates the +Y axis of the bone rest to
match the bone direction.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_IterateIK3D_method_set_joint_rotation_axis}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**set_joint_rotation_axis**(index: `int<class_int>`{.interpreted-text
role="ref"}, joint: `int<class_int>`{.interpreted-text role="ref"},
axis:
`RotationAxis<enum_SkeletonModifier3D_RotationAxis>`{.interpreted-text
role="ref"})
`🔗<class_IterateIK3D_method_set_joint_rotation_axis>`{.interpreted-text
role="ref"}

Sets the rotation axis at `joint` in the bone chain\'s joint list.

The axes are based on the
`Skeleton3D.get_bone_rest()<class_Skeleton3D_method_get_bone_rest>`{.interpreted-text
role="ref"}\'s space, if `axis` is
`SkeletonModifier3D.ROTATION_AXIS_CUSTOM<class_SkeletonModifier3D_constant_ROTATION_AXIS_CUSTOM>`{.interpreted-text
role="ref"}, you can specify any axis.

**Note:** The rotation axis and the forward vector shouldn\'t be
colinear to avoid unintended rotation since
`ChainIK3D<class_ChainIK3D>`{.interpreted-text role="ref"} does not
factor in twisting forces.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_IterateIK3D_method_set_joint_rotation_axis_vector}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**set_joint_rotation_axis_vector**(index:
`int<class_int>`{.interpreted-text role="ref"}, joint:
`int<class_int>`{.interpreted-text role="ref"}, axis_vector:
`Vector3<class_Vector3>`{.interpreted-text role="ref"})
`🔗<class_IterateIK3D_method_set_joint_rotation_axis_vector>`{.interpreted-text
role="ref"}

Sets the rotation axis vector for the specified joint in the bone chain.

This vector is normalized by an internal process and represents the axis
around which the bone chain can rotate.

If the vector length is `0`, it is considered synonymous with
`SkeletonModifier3D.ROTATION_AXIS_ALL<class_SkeletonModifier3D_constant_ROTATION_AXIS_ALL>`{.interpreted-text
role="ref"}.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_IterateIK3D_method_set_target_node}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**set_target_node**(index: `int<class_int>`{.interpreted-text
role="ref"}, target_node: `NodePath<class_NodePath>`{.interpreted-text
role="ref"})
`🔗<class_IterateIK3D_method_set_target_node>`{.interpreted-text
role="ref"}

Sets the target node that the end bone is trying to reach.
