github_url

:   hide

# OpenXRSpatialComponentAnchorList {#class_OpenXRSpatialComponentAnchorList}

**Experimental:** This class may be changed or removed in future
versions.

**Inherits:**
`OpenXRSpatialComponentData<class_OpenXRSpatialComponentData>`{.interpreted-text
role="ref"} **\<** `RefCounted<class_RefCounted>`{.interpreted-text
role="ref"} **\<** `Object<class_Object>`{.interpreted-text role="ref"}

Object for storing the queries anchor result data.

::: rst-class
classref-introduction-group
:::

## Description

Object for storing the queries anchor result data when calling
`OpenXRSpatialEntityExtension.query_snapshot()<class_OpenXRSpatialEntityExtension_method_query_snapshot>`{.interpreted-text
role="ref"}.

::: rst-class
classref-reftable-group
:::

## Methods

::: rst-class
classref-section-separator
:::

------------------------------------------------------------------------

::: rst-class
classref-descriptions-group
:::

## Method Descriptions

::: {#class_OpenXRSpatialComponentAnchorList_method_get_entity_pose}
::: rst-class
classref-method
:::
:::

`Transform3D<class_Transform3D>`{.interpreted-text role="ref"}
**get_entity_pose**(index: `int<class_int>`{.interpreted-text
role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_OpenXRSpatialComponentAnchorList_method_get_entity_pose>`{.interpreted-text
role="ref"}

Returns the transform for the entity at this `index`.
