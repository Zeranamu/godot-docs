github_url

:   hide

# OpenXRSpatialComponentPlaneSemanticLabelList {#class_OpenXRSpatialComponentPlaneSemanticLabelList}

**Experimental:** This class may be changed or removed in future
versions.

**Inherits:**
`OpenXRSpatialComponentData<class_OpenXRSpatialComponentData>`{.interpreted-text
role="ref"} **\<** `RefCounted<class_RefCounted>`{.interpreted-text
role="ref"} **\<** `Object<class_Object>`{.interpreted-text role="ref"}

Object for storing the queries plane semantic label result data.

::: rst-class
classref-introduction-group
:::

## Description

Object for storing the queries plane semantic label result data when
calling
`OpenXRSpatialEntityExtension.query_snapshot()<class_OpenXRSpatialEntityExtension_method_query_snapshot>`{.interpreted-text
role="ref"}.

::: rst-class
classref-reftable-group
:::

## Methods

::: rst-class
classref-section-separator
:::

------------------------------------------------------------------------

::: rst-class
classref-descriptions-group
:::

## Enumerations

::: {#enum_OpenXRSpatialComponentPlaneSemanticLabelList_PlaneSemanticLabel}
::: rst-class
classref-enumeration
:::
:::

enum **PlaneSemanticLabel**:
`🔗<enum_OpenXRSpatialComponentPlaneSemanticLabelList_PlaneSemanticLabel>`{.interpreted-text
role="ref"}

::: {#class_OpenXRSpatialComponentPlaneSemanticLabelList_constant_PLANE_SEMANTIC_LABEL_UNCATEGORIZED}
::: rst-class
classref-enumeration-constant
:::
:::

`PlaneSemanticLabel<enum_OpenXRSpatialComponentPlaneSemanticLabelList_PlaneSemanticLabel>`{.interpreted-text
role="ref"} **PLANE_SEMANTIC_LABEL_UNCATEGORIZED** = `1`

Uncategorized plane.

::: {#class_OpenXRSpatialComponentPlaneSemanticLabelList_constant_PLANE_SEMANTIC_LABEL_FLOOR}
::: rst-class
classref-enumeration-constant
:::
:::

`PlaneSemanticLabel<enum_OpenXRSpatialComponentPlaneSemanticLabelList_PlaneSemanticLabel>`{.interpreted-text
role="ref"} **PLANE_SEMANTIC_LABEL_FLOOR** = `2`

Plane represents a floor.

::: {#class_OpenXRSpatialComponentPlaneSemanticLabelList_constant_PLANE_SEMANTIC_LABEL_WALL}
::: rst-class
classref-enumeration-constant
:::
:::

`PlaneSemanticLabel<enum_OpenXRSpatialComponentPlaneSemanticLabelList_PlaneSemanticLabel>`{.interpreted-text
role="ref"} **PLANE_SEMANTIC_LABEL_WALL** = `3`

Plane represents a wall.

::: {#class_OpenXRSpatialComponentPlaneSemanticLabelList_constant_PLANE_SEMANTIC_LABEL_CEILING}
::: rst-class
classref-enumeration-constant
:::
:::

`PlaneSemanticLabel<enum_OpenXRSpatialComponentPlaneSemanticLabelList_PlaneSemanticLabel>`{.interpreted-text
role="ref"} **PLANE_SEMANTIC_LABEL_CEILING** = `4`

Plane represents a ceiling.

::: {#class_OpenXRSpatialComponentPlaneSemanticLabelList_constant_PLANE_SEMANTIC_LABEL_TABLE}
::: rst-class
classref-enumeration-constant
:::
:::

`PlaneSemanticLabel<enum_OpenXRSpatialComponentPlaneSemanticLabelList_PlaneSemanticLabel>`{.interpreted-text
role="ref"} **PLANE_SEMANTIC_LABEL_TABLE** = `5`

Plane represents the surface of a table.

::: rst-class
classref-section-separator
:::

------------------------------------------------------------------------

::: rst-class
classref-descriptions-group
:::

## Method Descriptions

::: {#class_OpenXRSpatialComponentPlaneSemanticLabelList_method_get_plane_semantic_label}
::: rst-class
classref-method
:::
:::

`PlaneSemanticLabel<enum_OpenXRSpatialComponentPlaneSemanticLabelList_PlaneSemanticLabel>`{.interpreted-text
role="ref"} **get_plane_semantic_label**(index:
`int<class_int>`{.interpreted-text role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_OpenXRSpatialComponentPlaneSemanticLabelList_method_get_plane_semantic_label>`{.interpreted-text
role="ref"}

Returns the plane semantic label for the parent entity at this `index`.
