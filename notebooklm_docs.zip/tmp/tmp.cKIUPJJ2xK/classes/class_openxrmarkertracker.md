github_url

:   hide

# OpenXRMarkerTracker {#class_OpenXRMarkerTracker}

**Experimental:** This class may be changed or removed in future
versions.

**Inherits:**
`OpenXRSpatialEntityTracker<class_OpenXRSpatialEntityTracker>`{.interpreted-text
role="ref"} **\<**
`XRPositionalTracker<class_XRPositionalTracker>`{.interpreted-text
role="ref"} **\<** `XRTracker<class_XRTracker>`{.interpreted-text
role="ref"} **\<** `RefCounted<class_RefCounted>`{.interpreted-text
role="ref"} **\<** `Object<class_Object>`{.interpreted-text role="ref"}

Spatial entity tracker for our spatial entity marker tracking extension.

::: rst-class
classref-introduction-group
:::

## Description

Spatial entity tracker for our OpenXR spatial entity marker tracking
extension. These trackers identify entities in our real space detected
by a visual marker such as a QRCode or Aruco code, and map their
location to our virtual space.

::: rst-class
classref-reftable-group
:::

## Properties

::: rst-class
classref-reftable-group
:::

## Methods

::: rst-class
classref-section-separator
:::

------------------------------------------------------------------------

::: rst-class
classref-descriptions-group
:::

## Property Descriptions

::: {#class_OpenXRMarkerTracker_property_bounds_size}
::: rst-class
classref-property
:::
:::

`Vector2<class_Vector2>`{.interpreted-text role="ref"} **bounds_size** =
`Vector2(0, 0)`
`🔗<class_OpenXRMarkerTracker_property_bounds_size>`{.interpreted-text
role="ref"}

::: rst-class
classref-property-setget
:::

-   `void (No return value.)`{.interpreted-text role="abbr"}
    **set_bounds_size**(value:
    `Vector2<class_Vector2>`{.interpreted-text role="ref"})
-   `Vector2<class_Vector2>`{.interpreted-text role="ref"}
    **get_bounds_size**()

The bounds size for this marker.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_OpenXRMarkerTracker_property_marker_id}
::: rst-class
classref-property
:::
:::

`int<class_int>`{.interpreted-text role="ref"} **marker_id** = `0`
`🔗<class_OpenXRMarkerTracker_property_marker_id>`{.interpreted-text
role="ref"}

::: rst-class
classref-property-setget
:::

-   `void (No return value.)`{.interpreted-text role="abbr"}
    **set_marker_id**(value: `int<class_int>`{.interpreted-text
    role="ref"})
-   `int<class_int>`{.interpreted-text role="ref"} **get_marker_id**()

The marker ID for this marker, this is only returned for Aruco and April
Tag markers. Call
`get_marker_data()<class_OpenXRMarkerTracker_method_get_marker_data>`{.interpreted-text
role="ref"} for QRCode markers.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_OpenXRMarkerTracker_property_marker_type}
::: rst-class
classref-property
:::
:::

`MarkerType<enum_OpenXRSpatialComponentMarkerList_MarkerType>`{.interpreted-text
role="ref"} **marker_type** = `0`
`🔗<class_OpenXRMarkerTracker_property_marker_type>`{.interpreted-text
role="ref"}

::: rst-class
classref-property-setget
:::

-   `void (No return value.)`{.interpreted-text role="abbr"}
    **set_marker_type**(value:
    `MarkerType<enum_OpenXRSpatialComponentMarkerList_MarkerType>`{.interpreted-text
    role="ref"})
-   `MarkerType<enum_OpenXRSpatialComponentMarkerList_MarkerType>`{.interpreted-text
    role="ref"} **get_marker_type**()

The type of marker.

::: rst-class
classref-section-separator
:::

------------------------------------------------------------------------

::: rst-class
classref-descriptions-group
:::

## Method Descriptions

::: {#class_OpenXRMarkerTracker_method_get_marker_data}
::: rst-class
classref-method
:::
:::

`Variant<class_Variant>`{.interpreted-text role="ref"}
**get_marker_data**()
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_OpenXRMarkerTracker_method_get_marker_data>`{.interpreted-text
role="ref"}

Returns the marker data for this marker. This can return a
`String<class_String>`{.interpreted-text role="ref"} or
`PackedByteArray<class_PackedByteArray>`{.interpreted-text role="ref"}.
Only applicable to QR Code based markers.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_OpenXRMarkerTracker_method_set_marker_data}
::: rst-class
classref-method
:::
:::

`void (No return value.)`{.interpreted-text role="abbr"}
**set_marker_data**(marker_data:
`Variant<class_Variant>`{.interpreted-text role="ref"})
`🔗<class_OpenXRMarkerTracker_method_set_marker_data>`{.interpreted-text
role="ref"}

Sets the marker data for this marker.

**Note:** This should only be set by marker discovery logic.
