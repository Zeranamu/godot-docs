github_url

:   hide

# AudioStreamPlaybackOggVorbis {#class_AudioStreamPlaybackOggVorbis}

**Inherits:**
`AudioStreamPlaybackResampled<class_AudioStreamPlaybackResampled>`{.interpreted-text
role="ref"} **\<**
`AudioStreamPlayback<class_AudioStreamPlayback>`{.interpreted-text
role="ref"} **\<** `RefCounted<class_RefCounted>`{.interpreted-text
role="ref"} **\<** `Object<class_Object>`{.interpreted-text role="ref"}

::: {.container .contribute}
There is currently no description for this class. Please help us by
[contributing
one](https://contributing.godotengine.org/en/latest/documentation/class_reference.html)!
:::
