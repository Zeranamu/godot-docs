github_url

:   hide

# FABRIK3D {#class_FABRIK3D}

**Inherits:** `IterateIK3D<class_IterateIK3D>`{.interpreted-text
role="ref"} **\<** `ChainIK3D<class_ChainIK3D>`{.interpreted-text
role="ref"} **\<** `IKModifier3D<class_IKModifier3D>`{.interpreted-text
role="ref"} **\<**
`SkeletonModifier3D<class_SkeletonModifier3D>`{.interpreted-text
role="ref"} **\<** `Node3D<class_Node3D>`{.interpreted-text role="ref"}
**\<** `Node<class_Node>`{.interpreted-text role="ref"} **\<**
`Object<class_Object>`{.interpreted-text role="ref"}

Position based forward and backward reaching inverse kinematics solver.

::: rst-class
classref-introduction-group
:::

## Description

**FABRIK3D** is position based IK, allowing precise and accurate
tracking of targets. It\'s ideal for simple chains without limitations.

The resulting twist around the forward vector will always be kept from
the previous pose.

**Note:** When the target is close to the root, it tends to produce
zig-zag patterns, resulting in unnatural visual movement.
