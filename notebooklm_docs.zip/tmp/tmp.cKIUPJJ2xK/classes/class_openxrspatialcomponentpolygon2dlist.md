github_url

:   hide

# OpenXRSpatialComponentPolygon2DList {#class_OpenXRSpatialComponentPolygon2DList}

**Experimental:** This class may be changed or removed in future
versions.

**Inherits:**
`OpenXRSpatialComponentData<class_OpenXRSpatialComponentData>`{.interpreted-text
role="ref"} **\<** `RefCounted<class_RefCounted>`{.interpreted-text
role="ref"} **\<** `Object<class_Object>`{.interpreted-text role="ref"}

Object for storing the queries polygon2d result data.

::: rst-class
classref-introduction-group
:::

## Description

Object for storing the queries 2D polygon result data when calling
`OpenXRSpatialEntityExtension.query_snapshot()<class_OpenXRSpatialEntityExtension_method_query_snapshot>`{.interpreted-text
role="ref"}.

::: rst-class
classref-reftable-group
:::

## Methods

::: rst-class
classref-section-separator
:::

------------------------------------------------------------------------

::: rst-class
classref-descriptions-group
:::

## Method Descriptions

::: {#class_OpenXRSpatialComponentPolygon2DList_method_get_transform}
::: rst-class
classref-method
:::
:::

`Transform3D<class_Transform3D>`{.interpreted-text role="ref"}
**get_transform**(index: `int<class_int>`{.interpreted-text role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_OpenXRSpatialComponentPolygon2DList_method_get_transform>`{.interpreted-text
role="ref"}

Returns the transform for positioning our polygon for the entity at this
`index`.

::: rst-class
classref-item-separator
:::

------------------------------------------------------------------------

::: {#class_OpenXRSpatialComponentPolygon2DList_method_get_vertices}
::: rst-class
classref-method
:::
:::

`PackedVector2Array<class_PackedVector2Array>`{.interpreted-text
role="ref"} **get_vertices**(snapshot:
`RID<class_RID>`{.interpreted-text role="ref"}, index:
`int<class_int>`{.interpreted-text role="ref"})
`const (This method has no side effects. It doesn't modify any of the instance's member variables.)`{.interpreted-text
role="abbr"}
`🔗<class_OpenXRSpatialComponentPolygon2DList_method_get_vertices>`{.interpreted-text
role="ref"}

Returns the polygon vertices for the entity at this `index`.
