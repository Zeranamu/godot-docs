# Community channels {#doc_community_channels}

So, where is the Godot community and where can you ask questions and get
help?

This page used to list the various official and user-supported Godot
communities. That list is now available on the [Godot
website](https://godotengine.org/community).

## Language-based communities

See the [User groups](https://godotengine.org/community/user-groups)
page of the website for a list of local communities.
